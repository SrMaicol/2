# Astha TV — Android TV base project

Base compilable de una interfaz de streaming para Android TV / Google TV / Fire TV.

## Incluido

- Kotlin + Jetpack Compose
- Interfaz 10-foot en landscape
- Navegación por D-Pad/foco
- `LazyColumn` + `LazyRow` con claves estables
- Animación premium de foco sin bordes
- Carga de imágenes con Coil 3
- Pantalla Home + Detalles
- Reproductor Media3 / ExoPlayer
- Cliente asíncrono de Stremio Addons v3 (`manifest`, `catalog`, `meta`, `stream`, `subtitles`)
- Contrato `TorrentEngine` preparado para implementar libtorrent/JNI
- Launcher para TV (`LEANBACK_LAUNCHER`)

## Requisitos

- Android Studio compatible con AGP 9.4
- JDK 17
- Android SDK 37
- Gradle 9.6 (bootstrap `gradlew` incluido; descarga la distribución fijada en el primer build)

## Compilar

1. Descomprime el ZIP.
2. Android Studio → **Open** → selecciona la carpeta `AsthaTV`.
3. Espera el Gradle Sync.
4. Instala SDK 37 si Android Studio lo solicita.
5. Build → Build APK(s).

O por terminal:

```bash
./gradlew assembleDebug
```

APK esperado:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Probar

Puedes usar un emulador Android TV/Google TV en Android Studio o un dispositivo Android TV con depuración ADB.

La pantalla de detalles incluye un vídeo público de prueba para comprobar Media3.

## Stremio Addons

Cliente:

```text
app/src/main/java/com/asthatv/app/data/StremioAddonClient.kt
```

Ejemplo:

```kotlin
val addon = StremioAddonClient("https://TU-ADDON/manifest.json")
val manifest = addon.manifest()
val streams = addon.streams("movie", "tt1375666")
```

No registres en logs URLs privadas de addons: pueden contener tokens.

## Torrent/P2P

El ZIP contiene la arquitectura/contrato, **no una librería binaria de libtorrent**. El punto de integración es:

```text
app/src/main/java/com/asthatv/app/player/PlaybackSource.kt
```

La implementación final debe ser un módulo C++/JNI que gestione metadata, DHT, peers, selección de archivo y prioridades/deadlines de piezas, y exponga al reproductor una fuente local/seekable. Mantener esta capa separada evita bloquear la UI.

Usa P2P únicamente para contenido que tengas derecho a reproducir.

## Nota sobre orientación

La Activity solicita `landscape`. En Android TV es el comportamiento esperado. Android moderno puede ignorar restricciones de orientación en determinadas pantallas grandes, por lo que la UI también está diseñada como landscape-first.
