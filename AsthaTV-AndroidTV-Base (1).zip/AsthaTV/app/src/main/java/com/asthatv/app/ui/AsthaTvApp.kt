package com.asthatv.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.*
import com.asthatv.app.model.MediaItemUi
import com.asthatv.app.ui.screens.DetailsScreen
import com.asthatv.app.ui.screens.HomeScreen
import com.asthatv.app.ui.screens.PlayerScreen

private sealed interface Screen {
    data object Home : Screen
    data class Details(val media: MediaItemUi) : Screen
    data class Player(val url: String) : Screen
}

@Composable
fun AsthaTvApp() {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    when (val current = screen) {
        Screen.Home -> HomeScreen(onOpen = { screen = Screen.Details(it) })
        is Screen.Details -> {
            BackHandler { screen = Screen.Home }
            DetailsScreen(
                media = current.media,
                onBack = { screen = Screen.Home },
                // Public sample video for verifying Media3 playback only.
                onPlayDemo = {
                    screen = Screen.Player(
                        "https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"
                    )
                }
            )
        }
        is Screen.Player -> {
            BackHandler { screen = Screen.Home }
            PlayerScreen(current.url, onBack = { screen = Screen.Home })
        }
    }
}
