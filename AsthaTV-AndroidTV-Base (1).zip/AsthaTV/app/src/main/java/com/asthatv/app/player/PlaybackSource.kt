package com.asthatv.app.player

sealed interface PlaybackSource {
    data class Direct(val url: String) : PlaybackSource
    data class Torrent(val infoHash: String, val fileIndex: Int? = null) : PlaybackSource
    data class Magnet(val uri: String) : PlaybackSource
}

/**
 * Contract for the future native libtorrent/JNI module.
 * The UI/player depend on this interface, not on libtorrent itself.
 */
interface TorrentEngine {
    suspend fun prepare(source: PlaybackSource.Torrent): String
    suspend fun prepareMagnet(source: PlaybackSource.Magnet): String
    fun stop()
}

class TorrentEngineNotInstalled : TorrentEngine {
    override suspend fun prepare(source: PlaybackSource.Torrent): String =
        error("Native torrent engine is not bundled in this base ZIP yet")

    override suspend fun prepareMagnet(source: PlaybackSource.Magnet): String =
        error("Native torrent engine is not bundled in this base ZIP yet")

    override fun stop() = Unit
}
